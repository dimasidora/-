﻿namespace FoodSupply.Core;

public class Class1
{

}
