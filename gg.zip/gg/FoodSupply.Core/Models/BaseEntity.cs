using System;

namespace FoodSupply.Core.Models
{
    /// <summary>
    /// Base class for all domain entities
    /// </summary>
    public abstract class BaseEntity
    {
        /// <summary>
        /// Unique identifier for the entity
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Date when the entity was created
        /// </summary>
        public DateTime CreatedAt { get; set; }

        /// <summary>
        /// Date when the entity was last modified
        /// </summary>
        public DateTime? ModifiedAt { get; set; }
    }
} 