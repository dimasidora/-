using System;

namespace FoodSupply.Core.Models
{
    /// <summary>
    /// Represents a delivery in the system
    /// </summary>
    public class Delivery : BaseEntity
    {
        /// <summary>
        /// Expected delivery date
        /// </summary>
        public DateTime ExpectedDeliveryDate { get; set; }

        /// <summary>
        /// Actual delivery date
        /// </summary>
        public DateTime? ActualDeliveryDate { get; set; }

        /// <summary>
        /// Status of the delivery
        /// </summary>
        public DeliveryStatus Status { get; set; }

        /// <summary>
        /// Quantity of products in the delivery
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// Total cost of the delivery
        /// </summary>
        public decimal TotalCost { get; set; }

        /// <summary>
        /// Notes about the delivery
        /// </summary>
        public string? Notes { get; set; }

        /// <summary>
        /// Associated product
        /// </summary>
        public Product? Product { get; set; }

        /// <summary>
        /// ID of the associated product
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Associated supplier
        /// </summary>
        public Supplier? Supplier { get; set; }

        /// <summary>
        /// ID of the associated supplier
        /// </summary>
        public int SupplierId { get; set; }
    }

    /// <summary>
    /// Enum representing the status of a delivery
    /// </summary>
    public enum DeliveryStatus
    {
        Pending,
        InTransit,
        Delivered,
        Cancelled
    }
} 