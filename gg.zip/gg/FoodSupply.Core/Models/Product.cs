using System;
using System.Collections.Generic;

namespace FoodSupply.Core.Models
{
    /// <summary>
    /// Represents a product in the system
    /// </summary>
    public class Product : BaseEntity
    {
        /// <summary>
        /// Name of the product
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Description of the product
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Current stock quantity
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// Minimum stock level that triggers reorder
        /// </summary>
        public int MinimumStockLevel { get; set; }

        /// <summary>
        /// Unit price of the product
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// Category of the product
        /// </summary>
        public string Category { get; set; }

        /// <summary>
        /// Supplier of the product
        /// </summary>
        public Supplier Supplier { get; set; }

        /// <summary>
        /// ID of the supplier
        /// </summary>
        public Guid SupplierId { get; set; }

        /// <summary>
        /// Collection of deliveries for this product
        /// </summary>
        public ICollection<Delivery> Deliveries { get; set; }
    }
} 