using System;
using System.Collections.Generic;

namespace FoodSupply.Core.Models
{
    /// <summary>
    /// Represents a supplier in the system
    /// </summary>
    public class Supplier : BaseEntity
    {
        /// <summary>
        /// Name of the supplier
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Contact person's name
        /// </summary>
        public string ContactPerson { get; set; } = string.Empty;

        /// <summary>
        /// Contact email address
        /// </summary>
        public string Email { get; set; } = string.Empty;

        /// <summary>
        /// Contact phone number
        /// </summary>
        public string Phone { get; set; } = string.Empty;

        /// <summary>
        /// Physical address of the supplier
        /// </summary>
        public string Address { get; set; } = string.Empty;

        /// <summary>
        /// Collection of products supplied by this supplier
        /// </summary>
        public ICollection<Product> Products { get; set; } = new List<Product>();

        /// <summary>
        /// Collection of deliveries from this supplier
        /// </summary>
        public ICollection<Delivery> Deliveries { get; set; }
    }
} 