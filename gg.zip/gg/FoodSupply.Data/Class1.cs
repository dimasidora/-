﻿namespace FoodSupply.Data;

public class Class1
{

}
