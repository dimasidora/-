using FoodSupply.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace FoodSupply.Data.Context
{
    public class FoodSupplyContext : DbContext
    {
        public FoodSupplyContext(DbContextOptions<FoodSupplyContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Delivery> Deliveries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Product>()
                .HasOne(p => p.Supplier)
                .WithMany(s => s.Products)
                .HasForeignKey(p => p.SupplierId);

            modelBuilder.Entity<Delivery>()
                .HasOne(d => d.Product)
                .WithMany()
                .HasForeignKey(d => d.ProductId);

            modelBuilder.Entity<Delivery>()
                .HasOne(d => d.Supplier)
                .WithMany()
                .HasForeignKey(d => d.SupplierId);
        }
    }
} 